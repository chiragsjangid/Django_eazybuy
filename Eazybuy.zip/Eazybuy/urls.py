from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from myapp import views
from myapp.views import Register, Login, Shop, logout, Cart
from myapp.templatetags.checkout import Checkout
from myapp.templatetags.order import OrderView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('gallery/', views.gallery),
    path('contact/', views.contact),
    path('about/', views.about),
    path('news/', views.news),
    path('shop/', Shop.as_view(), name='shop'),
    path('register/', Register.as_view(), name='register'),
    path('login/', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart/', Cart.as_view(), name='cart'),
    path('checkout', Checkout.as_view(), name='checkout'),
    path('order/', OrderView.as_view(), name='order'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
