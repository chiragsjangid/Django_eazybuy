from django.db import models

class News(models.Model):
    News_Title = models.CharField(max_length=200)
    News_URL = models.URLField(max_length=200)