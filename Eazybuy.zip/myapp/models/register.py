from django.db import models


class Reg(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=100)

    def register(self):
        self.save()

    def userexists(self):
        if Reg.objects.filter(email=self.email):
            return True

        return False

    @staticmethod
    def userbyemail(email):
        try:
            return Reg.objects.get(email=email)
        except:
            return False

