from django.db import models


class Member(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    contact = models.IntegerField()
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
