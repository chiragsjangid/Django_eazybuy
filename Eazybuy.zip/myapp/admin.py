from django.contrib import admin
from .models.member import Member
from .models.galleryimage import Galleryimage
from .models.news import News
from .models.category import Category
from .models.product import Product
from .models.register import Reg
from .models.order import Order


class MemberAdmin(admin.ModelAdmin):
    list_display = ['name', 'address', 'contact', 'email', 'password']


class CategoryAdmin(admin.ModelAdmin):
    list_display = ['category_name']


class NewsAdmin(admin.ModelAdmin):
    list_display = ['News_Title', 'News_URL']


class RegAdmin(admin.ModelAdmin):
    list_display = ['fname', 'lname', 'email', 'password']


class ProductAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'Price']


class OrderAdmin(admin.ModelAdmin):
    list_display = ['name', 'product', 'customer', 'quantity', 'address', 'phone', 'price', 'date']

# Register your models here.


admin.site.register(Member, MemberAdmin)

admin.site.register(Galleryimage)

admin.site.register(News, NewsAdmin)

admin.site.register(Category, CategoryAdmin)

admin.site.register(Product, ProductAdmin)

admin.site.register(Reg, RegAdmin)

admin.site.register(Order, OrderAdmin)