from django import template
from django.views import View
from django.shortcuts import render, redirect
from myapp.models.product import Product
from myapp.models.order import Order
from myapp.models.register import Reg

register = template.Library()


class Checkout(View):
    def post(self, request):
        name = request.POST.get('name')
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        for product in products:
            order = Order(customer=Reg(id=customer),
                            product=product,
                            price=product.Price,
                            quantity=cart.get(str(product.id)),
                            address=address,
                            phone=phone,
                            name=name,)

            print(order.placeOrder())
        return redirect('cart')











