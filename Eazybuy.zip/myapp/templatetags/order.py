from django import template
from django.views import View
from django.shortcuts import render, redirect
from myapp.models.order import Order
from myapp.middlewares.authentication import authentication
from django.utils.decorators import method_decorator

register = template.Library()


class OrderView(View):
    @method_decorator(authentication)
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_order_by_customer(customer)
        return render(request, 'order.html', {'orders': orders})


@register.filter(name='items_in_order')
def items_in_order(orders):
    total = 0
    for p in orders:
        total += p.quantity
    return total


@register.filter(name='order_total')
def order_total(orders):
    sum = 0
    for p in orders:
        sum += p.product.Price * p.quantity
    return sum


@register.filter(name='shipping')
def shipping(orders):
    if int(order_total(orders)) <= 500:
        shipping = 50.00
    else:
        shipping = 00.00
    return shipping


@register.filter(name='final_total')
def final_total(orders):
    total = (shipping(orders)) + order_total(orders)
    return total


@register.filter(name='customer_name')
def customer_name(orders):
    name = None
    for user in orders:
        return user.name
        break


@register.filter(name='customer_address')
def customer_address(orders):
    address = None
    for user in orders:
        address = user.address
        break
    return address


@register.filter(name='customer_phone')
def customer_phone(orders):
    phone = None
    for user in orders:
        phone = user.phone
        break
    return phone


@register.filter(name='order_date')
def order_date(orders):
    date = None
    for user in orders:
        date = user.date
        break
    return date