from django import template


register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return True
    return False


@register.filter(name='items_in_cart')
def items_in_cart(products, cart):
    total = 0
    for p in products:
        total += cart_quantity(p, cart)
    return total


@register.filter(name='cart_quantity')
def cart_quantity(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)

    return 0


@register.filter(name='price_total')
def price_total(product, cart):
    return product.Price * cart_quantity(product, cart)


@register.filter(name='cart_total')
def cart_total(products, cart):
    sum = 0
    for p in products:
        sum += p.Price * cart_quantity(p, cart)
    return sum


@register.filter(name='shipping')
def shipping(products, cart):
    if cart_total(products, cart) <= 500:
        shipping = 50.00
    else:
        shipping = 00.00
    return shipping


@register.filter(name='final_total')
def final_total(products, cart):
    total = (shipping(products, cart)) + cart_total(products, cart)
    return total

