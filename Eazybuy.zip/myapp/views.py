from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from .models.galleryimage import Galleryimage
from .models.news import News
from .models.product import Product
from .models.register import Reg
from .models.category import Category
from django.views import View


# Create your views here.
def index(request):
    return render(request, 'index.html')


def gallery(request):
    data = Galleryimage.objects.all()
    return render(request, "gallery.html", {'data': data})


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'contact.html')


def news(request):
    data = News.objects.all()
    return render(request, "news.html", {'data': data})


class Shop(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session.cart = {}
        products = None
        categories = Category.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            products = Product.objects.filter(category=categoryID)
        else:
            products = Product.objects.all()
            print('you are : ', request.session.get('customer_email'))
        return render(request, "shop.html", {'products': products, 'categories': categories})

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1

        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print(request.session['cart'])
        return redirect('shop')


class Login(View):
    return_url = ''
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Reg.userbyemail(email)
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['customer_email'] = customer.email
                return redirect("shop")

            else:
                error_message = 'Invalid password !!'
                return render(request, 'login.html', {'error': error_message})
        else:
            error_message = 'User does not exist with this email !! Please create an account.'
            return render(request, 'login.html', {'error': error_message})


class Register(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self,request):
        error_message = None
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        password = request.POST.get('password')
        value = {
                'fname': fname,
                'lname': lname,
                'email': email,
                'password': password,
                }
        user = Reg(fname=fname,
                    lname=lname,
                    email=email,
                    password=password,
                    )

        # email Validation

        if user.userexists():
            error_message = 'This email is already registered with a user.'
            return render(request, 'register.html', {'error': error_message, 'value': value})

        # saving user

        if not error_message:
            user.password = make_password(user.password)  # password hashing
            user.save()
            error_message = 'Sign up success !!, Please login to continue.'
            return render(request, 'login.html', {'error': error_message})

        else:
            return render(request, 'register.html', {'error': error_message})


def logout(request):
    request.session.clear()
    return redirect('login')


class Cart(View):
    def get(self, request):
        cart = request.session.get('cart')
        if cart:
            ids = list(request.session.get('cart').keys())
            products = Product.get_products_by_id(ids)
            print(products)
            print('you are : ', request.session.get('customer_email'))
            return render(request, 'cart.html', {'products': products})
        else:
            request.session.cart = {}
            return render(request, 'cart.html')

